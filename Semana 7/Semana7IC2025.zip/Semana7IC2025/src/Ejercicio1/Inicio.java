
package Ejercicio1;

import java.util.Scanner;


public class Inicio {
    
    
    public static void main(String[] args) {
        
        
        Estudiantes e1 = new Estudiantes("Ronald", "Arias", "Porgra");
        Profesores p1 = new Profesores("Ronald", "Arias");
        
        e1.mostraRol();
        
        
        
    }
    
    
    
    
}
