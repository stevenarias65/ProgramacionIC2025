package EjercicioArreglos;

public class Ejercicio5 {

    public static void main(String[] args) {

        int[][] numeros = {
            {1, 2, 3}, 
            {4, 5, 6}, 
            {7, 8, 9}
        };

    }

}
