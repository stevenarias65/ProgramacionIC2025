
package EjercicioArreglos;


public class Ejercicio2 {
    
    public static void main(String[] args) {
        
        
        String[] palabras = {"Steven","Arias","Fallas"};
        
        
        System.out.println(palabras.length);
        
        
        
    }
    
    
}
