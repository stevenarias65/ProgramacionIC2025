
package EjercicioArreglos;

import java.util.ArrayList;


public class Ejercicio7 {
    
    
    public static void main(String[] args) {
        
        ArrayList<String> nombre = new ArrayList<>();
        
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        nombre.add("Ronald");
        
        System.out.println(nombre.get(0));
        
        
        
        for (String i : nombre) {
            System.out.println(i);
        }
                
                
        
        
        
        
    }
    
    
    
}
