
package Ejercicio1;

import java.util.Scanner;


public class Segundo {
    
     public static void main(String[] args){
         
         //Creando el objeto
         Scanner entrada = new Scanner(System.in);
         
         System.out.println("Por favor digite un numero");
         int numero = entrada.nextInt();
         float peso = entrada.nextFloat();
         System.out.println("Por favor digite un nombre");
         String nombre = entrada.next();
         
         System.out.println(numero);
         System.out.println(peso);
         System.out.println(nombre);
         
         
         
         
         
         
     }
    
    
}
