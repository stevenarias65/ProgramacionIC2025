
package Ejercicio1;


public class Primero {
    
    public static void main(String[] args){
        
        System.out.print("Hola mundo \n");
        System.out.print("Soy Steven \n");
        System.out.print(12 + "\n");
        System.out.println("------");
        System.out.println("Hola mundo");
        System.out.println("Soy Steven");
        System.out.println(12);
        
        byte numero = 127;
        short numeroGrande = 32767;
        long muyGrande = 128318123131L;
        System.out.println(muyGrande);
        
        float decimalFloat = 12312.21F;
        double decimalDouble = 123123.12;
        
        boolean logicos = true;
        boolean logico = false;
        
        char valor = 'a';
        
        
      
        
        
        int edad = 18, edad2 = 20;
        
        char valorChar = '♓';
        System.out.println(valorChar);
        
        
        
        String nombre = "Ronald Steven";
        String apellidos = "Arias Fallas";
        
        String num1 = "12";
        String num2 = "20";
        
        String nombreCompleto = nombre +" "+ apellidos;
        
        int tamañoString = apellidos.length();
        
        
        
        String  Saludo1 = "hola";
        String Saludo2 = "Hola";
        
        System.out.println(nombre.substring(0,8));
        
        
        System.out.println(Saludo1.startsWith("H"));
        
        String edadString = String.valueOf(edad);
        
        int num1Entero = Integer.parseInt(num1);
        double num2double = Double.parseDouble(num2);
        
        
        System.out.println(Saludo1.equalsIgnoreCase(Saludo2));
      
        
        
        
        //vamos a crear 2 varibles de tipo de entero con valores 10 y 3 
        //y vamos a crear sus respectiva suma, resta, multi, divicion-> 
        //lo guardamos en sus prespectivas varibles
        //Mostrarlo en pantalla
        
         
    }
       
    
}
